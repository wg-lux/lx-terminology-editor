from __future__ import annotations

import os
from importlib.metadata import distribution
from pathlib import Path


def _packaged_static_root() -> Path:
    dist = distribution("lx-terminology-editor")
    for entry in dist.files or []:
        if str(entry).endswith("share/lx-terminology-editor/index.html"):
            return Path(dist.locate_file(entry)).parent
    raise RuntimeError("Packaged LX terminology editor static assets were not found.")


os.environ.setdefault("LX_TERMINOLOGY_EDITOR_STATIC_ROOT", str(_packaged_static_root()))

from server import main  # noqa: E402


__all__ = ["main"]
