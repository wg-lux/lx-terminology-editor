export async function publishBundle({ state, fileMap }) {
  const response = await fetch("/api/publish", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      state,
      file_map: fileMap,
      publish: {
        name: state?.bundle?.name || "",
      },
    }),
  });

  const payload = await response.json();
  if (!response.ok) {
    const error = new Error(payload.error || "Veröffentlichung fehlgeschlagen.");
    error.payload = payload;
    throw error;
  }

  return payload;
}
